export class UserData {
    id: number;
    name: string;
    progress: number;
    color: string;
    date : Date;
  }