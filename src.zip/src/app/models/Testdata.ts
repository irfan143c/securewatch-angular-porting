export class Testdata {
    id : string;
    name: string;
}