export class Names {
    firstName: string;
    lastName: string;
}