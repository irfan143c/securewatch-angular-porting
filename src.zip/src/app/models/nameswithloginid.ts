export class NamesWithLoginId {
    loginId : string;
    firstName: string;
    lastName: string;
}