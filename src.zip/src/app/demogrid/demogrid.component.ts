import { Component, OnInit, ViewChild, Input, ElementRef } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDatepickerInputEvent } from '@angular/material';
import { FormControl, FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { isNullOrUndefined } from 'util';
import { UserData } from '../models/UserData';
import { DataService } from '../services/data.service';
import { Angular5Csv } from 'angular5-csv/Angular5-csv';

import * as jsPdf from 'jspdf';
import 'jspdf-autotable';
import { DragulaService } from 'ng2-dragula';

@Component({
  selector: 'app-demogrid',
  templateUrl: './demogrid.component.html',
  styleUrls: ['./demogrid.component.css']
})
export class DemogridComponent implements OnInit {

  displayedColumns = [];
  dataSource: MatTableDataSource<UserData>;

  @Input() tableData: any;
  @Input() action: boolean;

  @ViewChild('table') table: ElementRef;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  filterForm: FormGroup;

  colValue: any;
  clauseValue: any;
  filterVal: any;
  dateFilterVal: any;

  allValues: any;

  showFilter: boolean = true;
  showDateFilter: boolean = false;

  clauses: any;
  // numberClauses = ['=', '≠', '<', '>', '≤', '≥'];
  stringClauses = ['contains', 'notContain', 'isEqualTo', 'isNotEqualTo'];

  totalColumns = [];

  showHideColumn = new FormControl();

  constructor(private fb: FormBuilder) { }

  ngOnInit() {

    let users = this.tableData;

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource(users);

    this.displayedColumns = Object.keys(users[0]);

    if (this.action == true) {
      this.displayedColumns.push('action');
    }


    this.totalColumns = this.displayedColumns;


    //FormCreation
    this.filterForm = this.fb.group({
      aliases: this.fb.array([this.createItem()])
    });

    // this.filterForm.controls['aliases'].valueChanges.subscribe(aliase => {
    //   this.clauseFilter(aliase);
    // })

    this.showHideColumn.setValue(this.displayedColumns);

    console.log(this.totalColumns);
    
    //Operation for filter---------------------------------------------------

    let totalFormFields = this.filterForm.controls['aliases'].value;
    
    totalFormFields[0].filterVal.valueChanges.subscribe((filterValue) => {
      console.log(filterValue);
      
    })

    // for (let i in totalFormFields) {
    //   totalFormFields[i].filterVal.valueChanges.subscribe((filterValue) => {
    //     // this.totalColumns['name'] = 
    //     console.log(filterValue);
        
    //   })

    // }



  }

  //Function for creating filter fields dynamically.
  createItem() {
    return this.fb.group({
      columnVal: '',
      clauseVal: '',
      filterVal: '',
      dateVal: ''
    });
  }

  get aliases() {
    return this.filterForm.get('aliases') as FormArray;
  }

  addFilter() {
    this.aliases.push(this.createItem());
  }

  removeFilter(i: number) {
    this.aliases.removeAt(i);
  }


  showData(data) {
    alert('ID is : ' + data);
  }

  // createForm() {
  //   this.filterForm = this.fb.group({
  //     columns: '',
  //     clauses: '',
  //     filterValue: '',
  //     dateValue: '',
  //     less : '',
  //     more : ''
  //   });


  //   // this.columnForm = this.fb.group({
  //   //   showHideColumn : [this.displayedColumns]
  //   // })
  // }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  // clauseFilter(aliases: any) {
  //   const totalValues = <FormArray>this.filterForm.controls['aliases'];

  //   for (let i in aliases) {
  //     // console.log(this.allValues[i].columnVal);

  //     this.colValue = aliases[i].columnVal;

  //     // this.colValue = totalValues.at(+i).get('columnVal').value;

  //     console.log(i);



  //     //code to clear fields on change of columns input
  //     if (this.colValue == 'id' || this.colValue == 'progress' || this.colValue == 'date') {
  //       this.clauses = this.numberClauses;
  //       // this.filterForm.controls['filterValue'].setValue('');

  //       // totalValues.at(+i).get('')
  //     }
  //     else {
  //       this.clauses = this.stringClauses;
  //       // this.filterForm.controls['filterValue'].setValue('');
  //     }

  //   }

  //   // console.log(this.allValues);



  // }

  applyFilter() {

    const totalValues = this.filterForm.controls['aliases'].value;

  }

  numberFilter() {
    if (this.clauseValue == '=') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] == filter;
      }
    }
    else if (this.clauseValue == '≠') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] != filter;
      }
    }
    else if (this.clauseValue == '<') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] < filter;
      }
    }
    else if (this.clauseValue == '>') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] > filter;
      }
    }
    else if (this.clauseValue == '≤') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] <= filter;
      }
    }
    else if (this.clauseValue == '≥') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] >= filter;
      }
    }
    // else if (this.clauseValue == '<>') {
    //   this.dataSource.filterPredicate = (data, filter) => {
    //     return data[this.colValue] < filter && data[this.colValue] > filter;
    //   }
    // }

  }

  stringFilter() {

    if (this.clauseValue == 'contains') {
      this.dataSource.filterPredicate = (data, filter) => {
        let dataStr = data[this.colValue];
        return dataStr.indexOf(filter) !== -1;
      }
    }
    else if (this.clauseValue == 'notContain') {
      this.dataSource.filterPredicate = (data, filter) => {
        let dataStr = data[this.colValue];
        return dataStr.indexOf(filter) === -1;
      }
    }
    else if (this.clauseValue == 'isEqualTo') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] == filter;
      }
    }
    else if (this.clauseValue == 'isNotEqualTo') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue] != filter;
      }
    }
  }

  dateFilter() {
    if (this.clauseValue == '=') {
      this.dataSource.filterPredicate = (data, filter) => {

        // console.log(data[this.colValue].getTime() == new Date(filter).getTime());

        return data[this.colValue].getTime() == new Date(filter).getTime();
      }
    }
    else if (this.clauseValue == '≠') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue].getTime() != new Date(filter).getTime();
      }
    }
    else if (this.clauseValue == '<') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue].getTime() < new Date(filter).getTime();
      }
    }
    else if (this.clauseValue == '>') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue].getTime() > new Date(filter).getTime();
      }
    }
    else if (this.clauseValue == '≤') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue].getTime() <= new Date(filter).getTime();
      }
    }
    else if (this.clauseValue == '≥') {
      this.dataSource.filterPredicate = (data, filter) => {
        return data[this.colValue].getTime() >= new Date(filter).getTime();
      }
    }
  }

  clearFilter() {
    this.filterForm.reset();
    this.applyFilter();
  }


  //Function for show / hide columns
  isCheck() {
    this.displayedColumns = this.showHideColumn.value;
  }

  //Excel File Export
  exportCsv() {
    new Angular5Csv(this.tableData, 'ExcelReport', { headers: this.displayedColumns });
  }

  //PDF File Export
  exportPdf() {

    let doc: any = new jsPdf('p', 'pt');
    let rows = [];

    this.tableData.forEach(key => {
      let data = [key.id, key.name, key.progress, key.color, key.date];
      rows.push(data);
    });

    doc.autoTable(this.displayedColumns, rows);
    doc.save('pdfdata.pdf');
  }

}